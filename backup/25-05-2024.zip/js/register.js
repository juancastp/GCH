document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('startWorkBtn').addEventListener('click', function () {
        handleRegister('inicio');
    });

    document.getElementById('pauseWorkBtn').addEventListener('click', function () {
        handleRegister('pausa', document.getElementById('pauseReason').value);
    });

    document.getElementById('resumeWorkBtn').addEventListener('click', function () {
        handleRegister('reinicio');
    });

    document.getElementById('stopWorkBtn').addEventListener('click', function () {
        handleRegister('parada');
    });

    function handleRegister(action, pauseReason = '') {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'register_hours.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                document.getElementById('response').innerHTML = xhr.responseText;
            }
        };
        xhr.send('action=' + action + '&pauseReason=' + pauseReason);
    }
});
