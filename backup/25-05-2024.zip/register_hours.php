<?php
session_start();
include('db_config.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT role_id, username, email, role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($role_id, $username, $email, $role_name);
$stmt->fetch();
$stmt->close();

if ($role_id === null || $username === null || $email === null || $role_name === null) {
    echo "Error: usuario no encontrado.";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'];
    $currentTime = date('Y-m-d H:i:s');

    if (isset($_SESSION['user_id'])) {
        $userId = $_SESSION['user_id'];
        switch ($action) {
            case 'inicio':
                $comment = "Inicio de jornada";
                $sql = "INSERT INTO registros_horas (user_id, hora, comentario) VALUES (?, ?, ?)";
                break;
            case 'pausa':
                $pauseReason = $_POST['pauseReason'];
                $comment = "Pausa: " . $pauseReason;
                $sql = "INSERT INTO registros_horas (user_id, hora, comentario) VALUES (?, ?, ?)";
                break;
            case 'reinicio':
                $comment = "Reinicio de jornada";
                $sql = "INSERT INTO registros_horas (user_id, hora, comentario) VALUES (?, ?, ?)";
                break;
            case 'parada':
                $comment = "Fin de jornada";
                $sql = "INSERT INTO registros_horas (user_id, hora, comentario) VALUES (?, ?, ?)";
                break;
            default:
                echo "Acción no válida.";
                exit();
        }
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iss", $userId, $currentTime, $comment);
        $stmt->execute();
        $stmt->close();
    } else {
        header("Location: login.php");
        exit();
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Horas - Control Horario</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="js/register.js"></script>
</head>
<body>
    <div class="container">
        <h2>Registrar Horas</h2>
        <button id="startWorkBtn" class="btn btn-primary">Inicio de Jornada</button>
        <button id="pauseWorkBtn" class="btn btn-warning">Pausa</button>
        <input type="text" id="pauseReason" placeholder="Motivo de la pausa">
        <button id="resumeWorkBtn" class="btn btn-success">Reinicio de Jornada</button>
        <button id="stopWorkBtn" class="btn btn-danger">Fin de Jornada</button>
        <div id="response"></div>
    </div>
</body>
</html>
